import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import dash
import dash_daq as daq
import plotly.express as px

app = dash.Dash(__name__,assets_folder="../")

app.css.config.serve_locally = True
app.scripts.config.serve_locally = True


app.layout = html.Div(
    [   "Input:",
        daq.NumericInput(
            min=0,
            max=1000,
            value=20,
            id="input_number",
        ),
        html.Div(id='numeric_input_output_1'),
        html.Img(src=app.get_asset_url('..Forest_1.jpg')),

    ]
)

@app.callback(Output("numeric_input_output_1",component_property="children"),[Input("input_number", "value")])

def numeric_input_output_1(input_number):
    y=input_number+5
    return 'The all-important value driving our business decisionsis {}.'.format(y)

if __name__ == '__main__':
    app.run_server(debug=False)